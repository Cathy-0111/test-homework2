#include<stdio.h>

int main(void) {
    int iIndex1, iIndex2, iSearchNumber, iCount = 0, m, n, iFlag = 0;
    int *ptr;
    
    scanf("%d %d %d", &m, &n, &iSearchNumber);
    
    int aColumn[m][n];
    
    ptr = &aColumn[0][0];
    
    srand(time(NULL));
    
    for (iIndex1 = 0; iIndex1 < m; iIndex1++)
    {
        for (iIndex2 = 0; iIndex2 < n; iIndex2++)
        {
            // aColumn[iIndex1][iIndex2] = rand() % (m * n) + 1;
            scanf("%d", &aColumn[iIndex1][iIndex2]);
        }
    }
    
    for (iIndex1 = 0; iIndex1 < m; iIndex1++)
    {
        for (iIndex2 = 0; iIndex2 < n; iIndex2++)
        {
            if (iSearchNumber == *(ptr + iIndex1 * n + iIndex2))
            {
                iFlag++;
                printf("%d %d\n", iIndex1, iIndex2);
            }
        }
    }
    
    if (!iFlag)
    {
        printf("-1 -1\n");
    }
    
    return 0;
}