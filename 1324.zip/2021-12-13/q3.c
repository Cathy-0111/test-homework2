#include <stdio.h>
int main()
{
  int matrix[8][8];
  int i, j, k, n, f;
  int min, max;
  for (i = 0; i < 8; i++)
    for (j = 0; j < 8; j++)
      matrix[i][j] = 0;
  scanf("%d", &n);
  for (i = 0; i < n; i++)
    for (j = 0; j < n; j++)
      scanf("%d", &matrix[i][j]);
  for (i = 0; i < n; i++)
    for (j = 0; j < n; j++)
      if (matrix[i][n] < matrix[i][j])
        matrix[i][n] = matrix[i][j];
  for (j = 0; j < n; j++)
  {
    matrix[n][j] = matrix[0][j];
    for (i = 0; i < n; i++)
      if (matrix[n][j] > matrix[i][j])
        matrix[n][j] = matrix[i][j];
  }
  f = 0;
  for (i = 0; i < n; i++)
  {
    for (j = 0; j < n; j++)
    {
      if (matrix[i][j] == matrix[n][j] && matrix[i][j] == matrix[i][n])
      {
        f = 1;
        break;
      }
    }
    if (f == 1)
      break;
  }
  if (f == 1)
  {
    printf("(%d,%d) = %d", i, j, matrix[i][j]);
  }
  else
  {
    printf("NONE");
  }
  return 0;
}