#include <stdio.h>
#include <stdlib.h>

int prime(int number)
{
    int i = 0, flag = 1;

    for (i = 2; i < number; i++)
    {
        if (0 == number % i)
        {
            flag = 0;
        }
    }
    
    return flag;
}

int main()
{
    int number, i = 0, tmp = 0;
   
    scanf("%d", &number);

    for (i = 2; i < number; i++)
    {
        tmp = number - i;
        if (prime(i) && prime(tmp) && tmp >= i)
        {
            printf("%d+%d\n", i, number - i);
        }
    }

    return 0;
}