#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    int i = 0;
    char string[100] = "";

    scanf("%[^\n]", string);

    for (i = 0; i < strlen(string); i++)
    {
        printf("%c", tolower(string[i]));
    }

    return 0;
}