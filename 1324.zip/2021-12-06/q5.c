#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char inputChar;

    scanf("%c", &inputChar);

    if (isalpha(inputChar))
    {
        if (isupper(inputChar))
        {
            printf("uppercase");
        }
        else
        {
            printf("lowercase");
        }
    }
    else
    {
        printf("special character");
    }

    return 0;
}