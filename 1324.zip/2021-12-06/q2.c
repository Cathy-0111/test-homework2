#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char string[100] = "\0", splitString[2];
    char *tmpPtr;

    scanf("%s %s",string, splitString);
    
    tmpPtr = strtok(string, splitString);
    while (tmpPtr != NULL)
    {
        printf("%s\n", tmpPtr);
        tmpPtr = strtok(NULL, splitString);
    }

    return 0;
}