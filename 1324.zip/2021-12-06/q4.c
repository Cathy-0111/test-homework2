#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    int i = 0;
    char string[100] = "", oldChar, newChar;

    scanf("%[^\n] %c %c", string, &oldChar, &newChar);


    for (i = 0; i < strlen(string); i++)
    {
        if (oldChar == string[i])
        {
            string[i] = newChar;
        }

        printf("%c", string[i]);
    }

    return 0;
}