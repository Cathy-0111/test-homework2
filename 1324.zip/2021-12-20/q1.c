#include <stdio.h>
#include <string.h>
#define SIZE 10
typedef struct studentScore{
    char id[ 10 ];
    char name[ 10 ];
    int score1;
    int score2;
    int score3;
} StudentScore;

void showMenu();
void showData( struct studentScore data[], int n);
int findData( struct studentScore data[], int n);
void sortScore( struct studentScore data[], int n, char op);
void showAverage( struct studentScore data[], int n);

void showMenu(){
    printf("%s\n", "===== menu =====");
    printf("%s\n", "f: find specific student data");
    printf("%s\n", "s: show all students' data");
    printf("%s\n", "d: show the sorted students' data (hight to low)");
    printf("%s\n", "a: show the sorted students' data (low to low)");
    printf("%s\n", "b: show the average score value");
    printf("%s\n", "q: quit");
    printf("%s", "function choice: ");
}

void showData( struct studentScore data[], int n){
    for(int i = 0; i < n; i++){
        printf("%s\t%s\t%d\t%d\t%d\n", data[i].id, data[i].name, 
                data[i].score1, data[i].score2, data[i].score3);
    }
    printf("----------\n");
}

int findData( struct studentScore data[], int n){
    char keyID[SIZE];
    printf("%s", "Student's ID: ");
    scanf( "%s", keyID);
    int i = 0;
    while( i < n){
        if(strcmp(data[i].id, keyID) == 0){
            printf("%s\t%s\t%d\t%d\t%d\n", data[i].id, data[i].name, 
                data[i].score1, data[i].score2, data[i].score3);
            return 1;
        }
        i++;
    }
    printf("%s\n\n", "No such student");
    return 0;
}

void sortScore( struct studentScore data[], int n, char op){
    StudentScore tmpScore;
    for( int i = 0; i < n; i++){
        for(int j=i+1;j <n;j++){
            if(op == 'd'){
                if( (data[i].score1+data[i].score2+data[i].score3) / 3 < 
                    (data[j].score1+data[j].score2+data[j].score3) / 3){
                    tmpScore = data[i];
                    data[i] = data[j];
                    data[j] = tmpScore;
                }
            }else{
                if( (data[i].score1+data[i].score2+data[i].score3) / 3 > 
                    (data[j].score1+data[j].score2+data[j].score3) / 3){
                    tmpScore = data[i];
                    data[i] = data[j];
                    data[j] = tmpScore;
                }
            }
            
        }
        printf("%s\t%s\t%d\t%d\t%d\n", data[i].id, data[i].name, 
                data[i].score1, data[i].score2, data[i].score3);
    }
    puts("");
}

void showAverage( struct studentScore data[], int n){
for(int i = 0; i < n; i++){
    printf("%s\t%s\t%.2f\n", data[i].id, data[i].name, 
                (float)(data[i].score1+data[i].score2+data[i].score3) / 3 );
    }
    printf("%s\n\n", "--**--**--**--**--");
}

int main(int argc, char const *argv[]){
    int n =1;
    char c ;
    scanf("%d", &n);
    StudentScore scores[ n ];
    for ( int i = 0; i < n; i++){
        scanf("%s", scores[i].id);
        scanf("%s", scores[i].name);
        scanf("%d", &scores[i].score1);
        scanf("%d", &scores[i].score2);
        scanf("%d", &scores[i].score3);
    }
    
    do{
        showMenu();
        scanf(" %c", &c);
        switch( c ){
            case 'f':
                findData( scores, n );
                break;
            case 's':
                showData( scores, n);
                break;
            case 'd':
                sortScore( scores, n , 'd');
                break;
            case 'a':
                sortScore( scores, n , 'a');
                break;
            case 'b':
                showAverage( scores, n);
                break;
            case 'q':
                printf("%s\n", "See u next time");
                break;
            default:
                printf("%s\n", "Error");
        }
    } while( c != 'q' );
    return 0;
}

/*
D11009923 David  80 90 90
D11009933 Jack   90 90 90
D11009943 Kevin  80 70 90
D11009823 Jannie 80 90 50
D11007923 Justin 80 70 90
D11069923 Allen  40 90 90
*/
