#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define SIZE 100

int main(int argc, char const *argv[]){
    char data[ SIZE ], inData[ SIZE ];
    char key[ SIZE ];
    short int cipher[ SIZE ], i = 0; 
    do {
        scanf(" %3hd", &cipher[i]);
        i++;
    } while( cipher[i-1] != -1);
    scanf(" %99s", key );
    i = 0;
    while( cipher[i] != -1){
        printf("%c", (char) (cipher[i] ^ key[ i % strlen(key)])); 
        i++;
    }
    puts("");
    return 0;
}
/*
This is a book 
iecs fcu
061001000026073000026073008073011006006002073099-1
005000110028005801010042003200420007006700230038004200400115010800090017008500000000000000000000-1
005000110028005801010042003200420007006700230038004200400115010800090017008500000000000000000000-1
fcuIECS
*/

