#include <stdio.h>

int main(int argc, char const *argv[]){
    short int netMask[4], ip[4];
    scanf("%hd%*c%hd%*c%hd%*c%hd", &netMask[0], 
           &netMask[1], &netMask[2], &netMask[3]);

    scanf("%hd%*c%hd%*c%hd%*c%hd", &ip[0], &ip[1], 
           &ip[2], &ip[3]);
    printf("%d.%d.%d.%d\n", netMask[0] & ip[0], 
           netMask[1] & ip[1], netMask[2] & ip[2], 
           netMask[3] & ip[3]);
    return 0;
}
