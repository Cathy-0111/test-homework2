#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define SIZE 100

int main(int argc, char const *argv[]){
    char plainText[SIZE];
    char keyText[SIZE];
    fgets(plainText, SIZE, stdin);
    fgets(keyText, SIZE, stdin);
    
    for(int i = 0 ;i < strlen(plainText); i++){
        printf("%03d",  (plainText[i] ^ keyText[ i % (strlen(keyText)-1)]));
    }
    puts("-01");
    return 0;
}
