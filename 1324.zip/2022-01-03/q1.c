#include stdio.h
#include stdlib.h
#include string.h

typedef struct score{
    unsigned int studentNum;
    char id[ 10 ];
    char lastName[ 15 ];
    char firstName[ 10 ];
    int scores[ 3 ];
} Score;

void menu();
void createFile( char fileName1, FILE filePtr);

int main(int argc, char const argv[]){
    FILE cfPtr = NULL;
    int operation, flag = 0;
    char fileName[ 40 ];
    char tmpStudentID[ 10 ];
    char choice;
    Score studScore = {0, , ,  , {0, 0, 0} };
    Score newStudScore = {0, , ,  , {0, 0, 0} };
    do{
        menu();
        scanf( %d, &operation );
        switch( operation ){
            case 0  exit
                break;
            case 1  create a new file
                printf(%s, File name );
                scanf( %s, fileName );
                createFile( fileName, cfPtr );
                break;
            case 2  Open an existed file
                printf(%s, File name );
                scanf( %s, fileName );
                if( ( cfPtr = fopen(fileName, rb+)) == NULL ){
                    puts(File can not be opened.);
                }else{
                    printf(%s%s%sn, File , fileName, is opened.);
                }
                break;
            case 3  Insert a score data
                if( cfPtr != NULL ){
                    printf(%s, Enter student number (1 to 50, 0 to end input) );
                    scanf(%d, &studScore.studentNum);
                    while( studScore.studentNum != 0){
                        printf(%s, nEnter ID, lastname, firstname, score1, score2, score3 );
                        fscanf(stdin, %10s%14s%9s%3d%3d%3d, studScore.id, studScore.lastName, studScore.firstName, 
                            &studScore.scores[0], &studScore.scores[1], &studScore.scores[2]);
                        
                        fseek(cfPtr, ( studScore.studentNum - 1)  sizeof(Score), SEEK_SET);
                        fwrite( &studScore, sizeof( Score ), 1, cfPtr);

                        printf(%s, Enter student number (1 to 50, 0 to end input) );
                        scanf( %d, &studScore.studentNum);
                    }
                }else{
                    printf(%sn, Please open data file first.);
                }
                break;
            case 4
                flag = 0;
                if( cfPtr != NULL ){
                    printf(%s, Enter student ID );
                    scanf( %s, tmpStudentID);
                    for( int i = 1;i = 50; i++){
                        fseek(cfPtr, ( i - 1)  sizeof(Score), SEEK_SET);
                        fread(&studScore, sizeof( Score ), 1, cfPtr); 
                        if ( strcmp(studScore.id, tmpStudentID) == 0 ){
                            printf(%dt%st%st%st%dt%dt%dn, studScore.studentNum, studScore.id, 
                                studScore.lastName, studScore.firstName, studScore.scores[0], studScore.scores[1], 
                                studScore.scores[2]);
                            flag = 1;
                            break;
                        }
                    }
                    if( flag == 0){
                        printf(%s%s%snn, There has no student ID , tmpStudentID,  in the file.);
                    }
                }else{
                    printf(%sn, Please open data file first.);
                }
                break;
            case 5
                flag = 0;
                if( cfPtr != NULL ){
                    printf(%s, Enter student ID );
                    scanf( %s, tmpStudentID);
                    for( int i = 1;i = 50; i++){
                        fseek(cfPtr, ( i - 1)  sizeof(Score), SEEK_SET);
                        fread(&studScore, sizeof( Score ), 1, cfPtr); 
                        if ( strcmp(studScore.id, tmpStudentID) == 0 ){
                            printf(%dt%st%st%st%dt%dt%dn, studScore.studentNum, studScore.id, 
                                studScore.lastName, studScore.firstName, studScore.scores[0], studScore.scores[1], 
                                studScore.scores[2]);
                            printf(%s, nEnter NEW ID, lastname, firstname, score1, score2, score3 );
                            fscanf(stdin,  %10s%14s%9s%3d%3d%3d, studScore.id, studScore.lastName, studScore.firstName, 
                                &studScore.scores[0], &studScore.scores[1], &studScore.scores[2]);
                            fseek(cfPtr, ( i - 1)  sizeof(Score), SEEK_SET);
                            fwrite( &studScore, sizeof( Score ), 1, cfPtr);

                            flag = 1;
                            break;
                        }
                    }
                    if( flag == 0){
                        printf(%s%s%snn, There has no student ID , tmpStudentID,  in the file.);
                    }
                }else{
                    printf(%sn, Please open data file first.);
                }
                break;
            case 6
                flag = 0;
                if( cfPtr != NULL ){
                    printf(%s, Enter student ID );
                    scanf( %s, tmpStudentID);
                    for( int i = 1;i = 50; i++){
                        fseek(cfPtr, ( i - 1)  sizeof(Score), SEEK_SET);
                        fread(&studScore, sizeof( Score ), 1, cfPtr); 
                        if ( strcmp(studScore.id, tmpStudentID) == 0 ){
                            printf(%dt%st%st%st%dt%dt%dn, studScore.studentNum, studScore.id, 
                                studScore.lastName, studScore.firstName, studScore.scores[0], studScore.scores[1], 
                                studScore.scores[2]);
                            printf(%s, nAre you sure want to delete data (Yn));
                            scanf( %c, &choice);
                            fseek(cfPtr, ( i - 1)  sizeof(Score), SEEK_SET);
                            fwrite( &newStudScore, sizeof( Score ), 1, cfPtr);
                            flag = 1;
                            break;
                        }
                    }
                    if( flag == 0){
                        printf(%s%s%snn, There has no student ID , tmpStudentID,  in the file.);
                    }
                }else{
                    printf(%sn, Please open data file first.);
                }
                break;
            case 7
                if( cfPtr != NULL ){
                    for( int i = 1;i = 50; i++){
                        fseek(cfPtr, ( i - 1)  sizeof(Score), SEEK_SET);
                        fread(&studScore, sizeof( Score ), 1, cfPtr); 
                        if ( studScore.studentNum != 0 ){
                            printf(%dt%st%st%st%dt%dt%dn, studScore.studentNum, studScore.id, 
                               studScore.lastName, studScore.firstName, studScore.scores[0], studScore.scores[1], 
                               studScore.scores[2]);
                        }
                    }
                }else{
                    printf(%sn, Please open data file first.);
                }
                break;
            default
                break;
        }
    } while( operation != 0);
    fclose( cfPtr );
    printf(%sn, Program is end!n);
    return 0;
}

void createFile( char fileName1, FILE filePtr){
    if( ( filePtr = fopen(fileName1, r)) == NULL ){
        if( ( filePtr = fopen(fileName1, wb)) == NULL ){
            puts(File can not be opened.);
        }else{
            Score blankScore = {0, , ,  , {0, 0, 0} };
            for(size_t i = 1; i= 50; i++){
                fwrite( &blankScore, sizeof(Score), 1, filePtr );
            }
            fclose( filePtr );
        }
    }else{
        char op;
        printf(%s[%s]%sn%s, The file , 
                fileName1, 
                 is existed.,
                Do you want to overwrite it (YN));
        scanf( %c, &op);
        if( op == 'Y'  op == 'y'){
            if( ( filePtr = fopen(fileName1, wb)) == NULL ){
                puts(File can not be opened.);
            }else{
                Score blankScore = {0, , ,  , {0, 0, 0} };
                for(size_t i = 1; i= 50; i++){
                    fwrite( &blankScore, sizeof(Score), 1, filePtr );
                }
                fclose( filePtr );
            }
        }
    }
}



void menu(){
    printf(%sn%sn%sn%sn%sn%sn%sn%sn%sn%s,
           Function menun --------------------,
           1 - create a new file.,
           2 - Open an existed file.,
           3 - Insert a score data,
           4 - Find a specific student data,
           5 - Update a specific student data,
           6 - Delete a specific student data,
           7 - List all of student score data,
           0 - Exit,
           = );
}